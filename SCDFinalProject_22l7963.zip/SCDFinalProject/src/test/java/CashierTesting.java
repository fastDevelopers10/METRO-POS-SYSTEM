public class CashierTesting {
}
